package admin;

import admin.AdminServlet;
import entities.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "EditClientsServlet")
public class EditUsersServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //PrintWriter pw = resp.getWriter();
        String usernameToEdit = req.getParameter("user");
        User userToEdit = AdminServlet.currentClients.getArrayOfClients().stream().filter(u -> u.getUsername().equals(usernameToEdit)).findFirst().orElse(null);
        String newName = req.getParameter("name");
        String newUsername = req.getParameter("username");
        if(userToEdit != null) {
            userToEdit.setName(newName);
            userToEdit.setUsername(newUsername);
        }
        RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/editUser.jsp");
        requestDispatcher.forward(req, resp);
        //pw.println("<div>Changes saved</div>");
    }
}
