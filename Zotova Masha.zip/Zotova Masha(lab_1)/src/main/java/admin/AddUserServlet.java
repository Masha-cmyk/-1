package admin;

import entities.User;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collections;

@WebServlet(name = "admin.AddUserServlet")
public class AddUserServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter pw = response.getWriter();
        int count = AdminServlet.currentClients.getArrayOfClients().size();
        String name = request.getParameter("name");
        String username = request.getParameter("username");
        String pwd = request.getParameter("pwd");
        AdminServlet.currentClients.getArrayOfClients().add(new User(count+1, name, username,pwd));
        RequestDispatcher requestDispatcher = getServletContext().getRequestDispatcher("/editUser.jsp");
        requestDispatcher.forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
