package admin;

import entities.Reserve;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;

@WebServlet(name = "admin.SearchServlet")
public class SearchServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Reserve reserves = new Reserve();
        String clientUsername = request.getParameter("name");
        String room = request.getParameter("room");
        String date = request.getParameter("date");
        ArrayList<Reserve> listOfReservesFound = reserves.getArrayOfReserves();
        if (!clientUsername.equals("")){
            listOfReservesFound = listOfReservesFound.stream().filter(p -> p.getClientUsername().equals(clientUsername)).collect(
                    ()->new ArrayList<Reserve>(),
                    (list, item)->list.add(item),
                    (list1, list2)-> list1.addAll(list2));
        }
        if(!room.equals("")){
            listOfReservesFound = listOfReservesFound.stream().filter(p -> p.getSevice().equals(room)).collect(
                    ()->new ArrayList<Reserve>(),
                    (list, item)->list.add(item),
                    (list1, list2)-> list1.addAll(list2));
        }
        if(!date.equals("")){
            listOfReservesFound = listOfReservesFound.stream().filter(p -> p.getDateOfReserve().equals(LocalDate.parse(date))).collect(
                    ()->new ArrayList<Reserve>(),
                    (list, item)->list.add(item),
                    (list1, list2)-> list1.addAll(list2));
        }
        PrintWriter pw = response.getWriter();
        pw.println("<html><body>");
        pw.println("<table border=\"1\" align = \"center\">\n" +
                "<caption>Reserves found</caption>\n" +
                "<tr><th>ID</th><th>Client</th><th>Room</th><th>Date</th><th>Reserve</th></tr>");
        listOfReservesFound.forEach(p -> pw.println("<tr><td>"+ p.getIdReserve() +
                "</td><td>"+ p.getClientUsername() + "</td><td>" + p.getSevice() +
                "</td><td>" + p.getDateOfReserve() + "</td><td>" + p.getNumOfReserve() +
                "</td></tr>"));
        pw.println("</table><br>");
        pw.println("<form action=\"admin\" method=\"get\">\n" +
                "<div align=\"center\">\n" +
                "<input type=\"submit\" value=\"Back\" name=\"back\"> <br>\n" +
                "</div>\n" +
                "</form>");
        pw.println("</body></html>");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
