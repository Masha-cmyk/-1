package entities;

import java.util.ArrayList;

public class Room {
    private int id;
    private String name;
    private int price;

    private ArrayList<Room> arrayOfRooms = new ArrayList<>();

    public Room(){
        arrayOfRooms.add(new Room(1, "standard", 450));
        arrayOfRooms.add(new Room(2, "business", 600));
        arrayOfRooms.add(new Room(3, "luxury", 900));
}

    public Room(int id, String name, int price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public ArrayList<Room> getArrayOfRooms() {
        return arrayOfRooms;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
