package entities;

import java.time.LocalDate;
import java.util.ArrayList;

public class Reserve{
    int idReserve;
    String clientUsername;
    String room;
    int numOfReserve;
    LocalDate dateOfReserve;

    ArrayList<Reserve> arrayOfReserves = new ArrayList<>();

    public Reserve(){
        arrayOfReserves.add(new Reserve(1,"igor77", "standard", 7, LocalDate.of(2020,9,14)));
        arrayOfReserves.add(new Reserve(2,"igor77", "business", 12, LocalDate.of(2020,9,19)));
        arrayOfReserves.add(new Reserve(3,"daria123", "luxury", 10, LocalDate.of(2020,10,5)));
        arrayOfReserves.add(new Reserve(4,"daria123", "business", 8, LocalDate.of(2020,10,4)));
        arrayOfReserves.add(new Reserve(5,"daria123", "standard", 6, LocalDate.of(2020,10,8)));
    }

    public Reserve(int idReserve, String clientName, String room, int numOfReserve, LocalDate dateOfReserve) {
        this.idReserve = idReserve;
        this.clientUsername = clientName;
        this.room = room;
        this.numOfReserve = numOfReserve;
        this.dateOfReserve = dateOfReserve;
    }

    public Reserve(String idReserve, String igor77, String standard, String yes, LocalDate of) {
    }

    public Reserve(int i, String igor77, String standard, String yes, LocalDate of) {
    }

    public ArrayList<Reserve> getArrayOfReserves() {
        return arrayOfReserves;
    }

    public int getIdReserve() {
        return idReserve;
    }

    public void setIdReserve(int idReserve) {
        this.idReserve = idReserve;
    }

    public int getNumOfReserve() {
        return numOfReserve;
    }

    public void setNumOfReserve(int numOfReserve) {
        this.numOfReserve = numOfReserve;
    }

    public String getClientUsername() {
        return clientUsername;
    }

    public void setClientUsername(String clientUsername) {
        this.clientUsername = clientUsername;
    }

    public String getSevice() {
        return room;
    }

    public void setSevice(String sevice) {
        this.room = room;
    }

    public LocalDate getDateOfReserve() {
        return dateOfReserve;
    }

    public void setDateOfReserve(LocalDate dateOfReserve) {
        this.dateOfReserve = dateOfReserve;
    }
}
