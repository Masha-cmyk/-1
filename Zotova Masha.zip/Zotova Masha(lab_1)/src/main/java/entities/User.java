package entities;

import java.util.HashSet;
import java.util.Objects;

public class User {
    private int id;
    private String name;
    private String username;
    private String password;

    private HashSet<User> arrayOfClients = new HashSet<>();

    public User() {
        arrayOfClients.add(new User(1, "Igor", "igor77", "12345"));
        arrayOfClients.add(new User(2, "Daria", "daria123", "12345"));
        arrayOfClients.add(new User(3, "MashaZ", "admin", "admin"));
    }

    public User(String username){
        this.username = username;
    }

    public User(int id, String name, String username, String password) {
        this.id = id;
        this.name = name;
        this.username = username;
        this.password = password;
    }

    public HashSet<User> getArrayOfClients() {
        return arrayOfClients;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User client = (User) o;
        return username.equals(client.username);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username);
    }
}

