
import entities.Reserve;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

@WebServlet(name = "ClientServlet")
public class ClientServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter pw = response.getWriter();
        Reserve reserves = new Reserve();
        Cookie[] cookies = request.getCookies();
        String currentUser = null;
        if(cookies != null) {
            for(Cookie cookie : cookies) {
                if (cookie.getName().equals("client")) {
                    currentUser = cookie.getValue();
                }
            }
        }
        pw.println("<html>");
        pw.println("<table border = '1' align = 'center'>");
        pw.println("<caption><b>Reserves</caption>");
        pw.println("<tr><th>ID</th><th>Client</th><th>Room</th><th>Date</th><th>Reserve</th></tr>");
        for(Reserve reserve: reserves.getArrayOfReserves()) {
            if(reserve.getClientUsername().equals(currentUser)) {
                pw.println("<tr>");
                pw.println("<td>" + reserve.getIdReserve() + "</td>");
                pw.println("<td>" + reserve.getClientUsername() + "</td>");
                pw.println("<td>" + reserve.getSevice() + "</td>");
                pw.println("<td>" + reserve.getDateOfReserve() + "</td>");
                pw.println("<td>" + reserve.getNumOfReserve() + "</td>");
                pw.println("</tr>");
            }
        }
        pw.println("</table><br><br>");
        pw.println("<form action=\"logout\" method=\"post\" align = \"center\">\n" +
                "<input type=\"submit\" value=\"Logout\" >\n" +
                "</form>");
        pw.println("</html>");
        pw.println("</html>");
    }
}
